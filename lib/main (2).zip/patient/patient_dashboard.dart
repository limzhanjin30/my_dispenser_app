import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../custom_bottom_nav.dart';
import '../login.dart';
import 'patient_schedule.dart'; 
import 'patient_link_machine.dart'; // NEW: Import linking page

class PatientDashboard extends StatefulWidget {
  final String userEmail;
  const PatientDashboard({super.key, required this.userEmail});

  @override
  State<PatientDashboard> createState() => _PatientDashboardState();
}

class _PatientDashboardState extends State<PatientDashboard> with TickerProviderStateMixin {
  String fullName = "Patient";
  String? linkedMachineId;
  Map<String, dynamic>? nextDose;
  List<dynamic> todaySchedule = [];
  bool _isLoading = true;

  late AnimationController _pulseController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _initAnimation();
    _fetchUserAndMachineData();
  }

  void _initAnimation() {
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 1.03).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  // --- STEP 1: FETCH PROFILE -> STEP 2: LISTEN TO SHARED MACHINE SLOTS ---
  Future<void> _fetchUserAndMachineData() async {
    final String cleanEmail = widget.userEmail.trim().toLowerCase();
    if (!mounted) return;
    setState(() => _isLoading = true);

    try {
      var userSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: cleanEmail)
          .limit(1)
          .get();

      if (userSnapshot.docs.isNotEmpty) {
        var userData = userSnapshot.docs.first.data();
        fullName = userData['name'] ?? "Patient";
        linkedMachineId = userData['linkedMachineId'];

        if (linkedMachineId != null) {
          // Listen specifically to the slots inside the shared machine
          FirebaseFirestore.instance
              .collection('machines')
              .doc(linkedMachineId)
              .snapshots()
              .listen((snap) {
            if (snap.exists) {
              _processMachineSlots(snap.data()!['slots'] ?? []);
            } else {
              if (mounted) setState(() => _isLoading = false);
            }
          }, onError: (err) {
             if (mounted) setState(() => _isLoading = false);
          });
        } else {
          // No machine linked: stop loading to show "Link Machine" prompt
          if (mounted) setState(() => _isLoading = false);
        }
      } else {
        if (mounted) setState(() => _isLoading = false);
      }
    } catch (e) {
      debugPrint("Dashboard Fetch Error: $e");
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _processMachineSlots(List<dynamic> slots) {
    DateTime now = DateTime.now();
    DateTime todayOnly = DateTime(now.year, now.month, now.day);
    
    List<Map<String, dynamic>> allFutureTimings = [];
    List<Map<String, dynamic>> todayDisplayList = [];
    final String myEmail = widget.userEmail.trim().toLowerCase();

    for (var slot in slots) {
      // SECURITY: Only show slots belonging to THIS patient in the shared machine
      if (slot['patientEmail'] != myEmail || slot['status'] == "Empty") continue;
      
      DateTime start = DateTime.parse(slot['startDate'] ?? now.toString());
      DateTime end = DateTime.parse(slot['endDate'] ?? now.toString());
      DateTime startDate = DateTime(start.year, start.month, start.day);
      DateTime endDate = DateTime(end.year, end.month, end.day);

      List<String> times = List<String>.from(slot['times'] ?? []);
      for (var t in times) {
        for (int dayOffset = 0; dayOffset <= 7; dayOffset++) {
          DateTime checkDate = todayOnly.add(Duration(days: dayOffset));
          if ((checkDate.isAtSameMomentAs(startDate) || checkDate.isAfter(startDate)) && 
              (checkDate.isAtSameMomentAs(endDate) || checkDate.isBefore(endDate))) {
            
            DateTime doseFullDateTime = _parseTimeString(t, checkDate);
            var doseMap = {
              "name": slot['medDetails'] ?? "Medication",
              "fullTime": doseFullDateTime,
              "displayTime": t,
              "isDone": slot['isDone'] ?? false,
              "slot": slot['slot'],
            };
            allFutureTimings.add(doseMap);
            if (dayOffset == 0) todayDisplayList.add(doseMap);
          }
        }
      }
    }

    allFutureTimings.sort((a, b) => (a['fullTime'] as DateTime).compareTo(b['fullTime'] as DateTime));
    todayDisplayList.sort((a, b) => (a['fullTime'] as DateTime).compareTo(b['fullTime'] as DateTime));

    Map<String, dynamic>? upcoming;
    try {
      upcoming = allFutureTimings.firstWhere((dose) => (dose['fullTime'] as DateTime).isAfter(now));
    } catch (e) {
      upcoming = null; 
    }

    // Pulse controller management based on time
    if (upcoming != null) {
      Duration diff = upcoming['fullTime'].difference(now);
      if (diff.inMinutes < 10 && diff.inMinutes >= 0) {
        _pulseController.repeat(reverse: true);
      } else {
        _pulseController.stop();
      }
    }

    if (mounted) {
      setState(() {
        todaySchedule = todayDisplayList;
        nextDose = upcoming;
        _isLoading = false;
      });
    }
  }

  DateTime _parseTimeString(String timeStr, DateTime referenceDate) {
    DateFormat format = DateFormat("hh:mm a");
    DateTime parsed = format.parse(timeStr);
    return DateTime(referenceDate.year, referenceDate.month, referenceDate.day, parsed.hour, parsed.minute);
  }

  String _getCountdownText(DateTime target) {
    Duration diff = target.difference(DateTime.now());
    int d = diff.inDays, h = diff.inHours % 24, m = diff.inMinutes % 60;
    List<String> parts = [];
    if (d > 0) parts.add("${d}d");
    if (h > 0) parts.add("${h}h");
    if (m > 0 || parts.isEmpty) parts.add("${m}m");
    return parts.join(" ");
  }

  @override
  Widget build(BuildContext context) {
    String currentDay = DateFormat('EEEE').format(DateTime.now());
    String currentDate = DateFormat('MMMM d, y').format(DateTime.now());

    return Scaffold(
      backgroundColor: const Color(0xFFF5F9FF),
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.logout, color: Colors.black87, size: 20),
          onPressed: () => Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) => const LoginPage()), (route) => false),
        ),
        title: const Text("Patient Dashboard", style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent, elevation: 0, centerTitle: true,
      ),
      body: _isLoading 
        ? const Center(child: CircularProgressIndicator())
        : RefreshIndicator(
          onRefresh: _fetchUserAndMachineData,
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(currentDay, currentDate),
                const SizedBox(height: 30),
                
                // CONDITIONAL RENDERING: Timer or Link Prompt
                linkedMachineId == null ? _buildLinkMachinePrompt() : _buildNextDoseCard(),
                
                const SizedBox(height: 30),
                const Text("Today's Progress", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 15),
                _buildScheduleList(),
              ],
            ),
          ),
        ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 0, role: "Patient", userEmail: widget.userEmail),
    );
  }

  Widget _buildHeader(String day, String date) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text("Hi, $fullName", style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          Text("$day, $date", style: const TextStyle(color: Colors.grey)),
          if (linkedMachineId != null) 
            Text("Machine: $linkedMachineId", style: const TextStyle(color: Colors.blue, fontSize: 10, fontWeight: FontWeight.bold)),
        ]),
        Icon(Icons.wifi, color: linkedMachineId != null ? Colors.green : Colors.grey),
      ],
    );
  }

  // --- NEW: LINK MACHINE PROMPT WIDGET ---
  Widget _buildLinkMachinePrompt() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(30),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(25)),
      child: Column(children: [
        const Icon(Icons.link_off, color: Colors.orange, size: 50),
        const SizedBox(height: 15),
        const Text("No Machine Connected", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const Text("Link your physical dispenser to see your schedule.", textAlign: TextAlign.center, style: TextStyle(color: Colors.grey, fontSize: 13)),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => PatientLinkMachine(userEmail: widget.userEmail))),
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1A3B70), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
          child: const Text("Link Machine Now", style: TextStyle(color: Colors.white)),
        )
      ]),
    );
  }

  Widget _buildNextDoseCard() {
    if (nextDose == null) return _buildStaticInfoCard("No Scheduled Doses", "Please check back later.");

    Duration diff = nextDose!['fullTime'].difference(DateTime.now());
    bool isUrgent = diff.inMinutes < 10 && diff.inMinutes >= 0;

    Widget cardContent = GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(
        builder: (context) => PatientSchedule(userEmail: widget.userEmail, initialDate: nextDose!['fullTime']))),
      child: Container(
        width: double.infinity, padding: const EdgeInsets.all(25),
        decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(25),
          border: isUrgent ? Border.all(color: Colors.red.shade200, width: 2) : null,
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 15)],
        ),
        child: Column(children: [
          Text("NEXT DOSE IN:", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: isUrgent ? Colors.red : Colors.blueGrey)),
          const SizedBox(height: 5),
          Text(_getCountdownText(nextDose!['fullTime']), style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold, color: isUrgent ? Colors.red : const Color(0xFF1A3B70))),
          Text("${nextDose!['name']} (Slot ${nextDose!['slot']})", style: const TextStyle(color: Colors.grey, fontSize: 16)),
        ]),
      ),
    );

    return isUrgent ? ScaleTransition(scale: _scaleAnimation, child: cardContent) : cardContent;
  }

  Widget _buildScheduleList() {
    if (linkedMachineId == null) return const Center(child: Text("Link a machine to view today's schedule.", style: TextStyle(color: Colors.grey)));
    if (todaySchedule.isEmpty) return const Center(child: Text("No medications for today."));

    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.grey.shade100)),
      child: ListView.separated(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        itemCount: todaySchedule.length,
        separatorBuilder: (context, index) => Divider(height: 1, color: Colors.grey.shade50),
        itemBuilder: (context, index) {
          final item = todaySchedule[index];
          bool isPast = (item['fullTime'] as DateTime).isBefore(DateTime.now());
          return ListTile(
            leading: Icon(item['isDone'] ? Icons.check_circle : Icons.radio_button_off, color: item['isDone'] ? Colors.green : (isPast ? Colors.red.shade300 : Colors.blueGrey.shade200)),
            title: Text(item['displayTime'], style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text("${item['name']} (Slot ${item['slot']})"),
            trailing: Text(item['isDone'] ? "Taken" : (isPast ? "Missed" : "Upcoming"), style: TextStyle(color: item['isDone'] ? Colors.green : (isPast ? Colors.red : Colors.blueGrey), fontWeight: FontWeight.bold, fontSize: 12)),
          );
        },
      ),
    );
  }

  Widget _buildStaticInfoCard(String title, String sub) {
    return Container(
      width: double.infinity, padding: const EdgeInsets.all(30),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(25)),
      child: Column(children: [
        const Icon(Icons.done_all, color: Colors.green, size: 40),
        const SizedBox(height: 10),
        Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Text(sub, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey, fontSize: 13)),
      ]),
    );
  }
}
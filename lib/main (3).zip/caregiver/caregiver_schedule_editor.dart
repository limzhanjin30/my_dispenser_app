import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; 
import 'package:intl/intl.dart'; 
import '../custom_bottom_nav.dart';

class CaregiverScheduleEditor extends StatefulWidget {
  final String userEmail;
  final String? initialTargetEmail;

  const CaregiverScheduleEditor({
    super.key, 
    required this.userEmail, 
    this.initialTargetEmail,
  });

  @override
  State<CaregiverScheduleEditor> createState() => _CaregiverScheduleEditorState();
}

class _CaregiverScheduleEditorState extends State<CaregiverScheduleEditor> {
  final TextEditingController _medDetailsController = TextEditingController();
  final TextEditingController _dayIntervalController = TextEditingController(text: "2");

  String _selectedMealCondition = "After Meal";
  String _selectedFrequency = "Everyday";
  DateTime _pickerTime = DateTime.now();
  
  DateTime _startDate = DateTime.now();
  DateTime _endDate = DateTime.now().add(const Duration(days: 7));

  List<String> _currentMedTimes = [];
  int _selectedIndex = 0; 
  String? _currentTargetEmail;
  String? _currentTargetMachineId; 
  bool _isLoading = false;

  List<Map<String, dynamic>> _machineSlots = []; 

  @override
  void initState() {
    super.initState();
    _currentTargetEmail = widget.initialTargetEmail;
    if (_currentTargetEmail != null) {
      _fetchPatientMachineInfo(_currentTargetEmail!);
    }
  }

  Stream<QuerySnapshot> _getLinkedPatientsStream() {
    return FirebaseFirestore.instance
        .collection('connections')
        .where('caregiverEmail', isEqualTo: widget.userEmail.trim().toLowerCase())
        .snapshots();
  }

  Future<void> _fetchPatientMachineInfo(String pEmail) async {
    if (!mounted) return;
    setState(() {
      _isLoading = true;
      _currentTargetMachineId = null; 
    });
    
    try {
      var userDoc = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: pEmail.trim().toLowerCase())
          .limit(1)
          .get();

      if (userDoc.docs.isNotEmpty) {
        String? machineId = userDoc.docs.first.get('linkedMachineId'); 
        if (machineId != null && machineId.isNotEmpty) {
          _currentTargetMachineId = machineId;
          _listenToMachineStatus();
        } else {
          if (mounted) setState(() => _isLoading = false);
        }
      } else {
        if (mounted) setState(() => _isLoading = false);
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _listenToMachineStatus() {
    if (_currentTargetMachineId == null) return;

    FirebaseFirestore.instance
        .collection('machines')
        .doc(_currentTargetMachineId)
        .snapshots()
        .listen((snap) {
      if (!mounted) return;
      if (snap.exists) {
        setState(() {
          _machineSlots = List<Map<String, dynamic>>.from(snap.data()!['slots']);
          _isLoading = false; 
        });
        _loadSlotIntoForm(_selectedIndex);
      } else {
        _initializeNewMachine();
      }
    }, onError: (err) {
      if (mounted) setState(() => _isLoading = false);
    });
  }

  void _initializeNewMachine() async {
    List<Map<String, dynamic>> initialSlots = List.generate(10, (index) => {
      "slot": index + 1,
      "status": "Empty",
      "patientEmail": "",
      "medDetails": "",
      "times": [],
      "startDate": "",
      "endDate": "",
      "frequency": "Everyday",
      "mealCondition": "After Meal",
      "isLocked": false,
      "isDone": false,
    });
    try {
      await FirebaseFirestore.instance.collection('machines').doc(_currentTargetMachineId).set({'slots': initialSlots});
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _loadSlotIntoForm(int index) {
    if (_machineSlots.isEmpty || index >= _machineSlots.length) return;
    var slot = _machineSlots[index];

    bool isMine = slot['patientEmail'] == _currentTargetEmail?.trim().toLowerCase();
    bool isEmpty = slot['status'] == "Empty";

    setState(() {
      _selectedIndex = index;
      if (isMine || isEmpty) {
        _medDetailsController.text = slot['medDetails'] ?? "";
        _selectedMealCondition = slot['mealCondition'] ?? "After Meal";
        
        // FIXED: Correctly parse "Every X Days" back from Firestore
        String freq = slot['frequency'] ?? "Everyday";
        if (freq.contains("Every") && freq.contains("Days") && !freq.startsWith("Everyday")) {
          _selectedFrequency = "Every X Days";
          // Extract the number from the string "Every 2 Days"
          _dayIntervalController.text = freq.split(' ')[1]; 
        } else {
          _selectedFrequency = freq;
        }

        _currentMedTimes = List<String>.from(slot['times'] ?? []);
        _startDate = (slot['startDate'] != null && slot['startDate'] != "") ? DateTime.parse(slot['startDate']) : DateTime.now();
        _endDate = (slot['endDate'] != null && slot['endDate'] != "") ? DateTime.parse(slot['endDate']) : DateTime.now().add(const Duration(days: 7));
      } else {
        _medDetailsController.text = "OCCUPIED BY OTHER PATIENT";
      }
    });
  }

  Future<void> _saveChanges() async {
    if (_currentTargetMachineId == null || _currentTargetEmail == null) return;
    var currentSlotState = _machineSlots[_selectedIndex];
    if (currentSlotState['status'] == "Occupied" && currentSlotState['patientEmail'] != _currentTargetEmail) {
      _showMsg("ACCESS DENIED: This slot is occupied.", Colors.red);
      return;
    }

    setState(() => _isLoading = true);

    // FIXED: Save interval logic to specifically format the string for the Patient Dashboard
    String finalFrequency = _selectedFrequency == "Every X Days" 
        ? "Every ${_dayIntervalController.text} Days" 
        : _selectedFrequency;

    _machineSlots[_selectedIndex] = {
      "slot": _selectedIndex + 1,
      "status": "Occupied",
      "patientEmail": _currentTargetEmail!.trim().toLowerCase(),
      "medDetails": _medDetailsController.text,
      "times": _currentMedTimes,
      "mealCondition": _selectedMealCondition,
      "frequency": finalFrequency,
      "startDate": DateFormat('yyyy-MM-dd').format(_startDate),
      "endDate": DateFormat('yyyy-MM-dd').format(_endDate),
      "isLocked": true, 
      "isDone": false,
      "adherenceStatus": "Upcoming",
      "lastTakenDate": "",
      "lastTakenTime": "",
    };

    try {
      await FirebaseFirestore.instance.collection('machines').doc(_currentTargetMachineId).update({
        "slots": _machineSlots,
        "lastUpdatedBy": widget.userEmail,
        "syncTime": FieldValue.serverTimestamp(),
      });
      _showMsg("Slot ${_selectedIndex + 1} Locked & Saved as $finalFrequency.", Colors.teal);
    } catch (e) {
      _showMsg("Sync Error: $e", Colors.red);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showMsg(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: color));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F9FF),
      appBar: AppBar(
        title: const Text("Schedule Editor", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16)),
        backgroundColor: Colors.white, centerTitle: true, elevation: 0.5,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _getLinkedPatientsStream(),
        builder: (context, snapshot) {
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) return _buildEmptyState("No linked patients found.");
          var patients = snapshot.data!.docs;

          return _isLoading 
            ? const Center(child: CircularProgressIndicator()) 
            : SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("1. Select Patient", style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1A3B70))),
                    const SizedBox(height: 10),
                    _buildPatientDropdown(patients),
                    const SizedBox(height: 25),
                    
                    if (_currentTargetEmail == null)
                      _buildPromptState("Please select a patient to begin.")
                    else if (_currentTargetMachineId == null) 
                      _buildNoMachineWarning()
                    else ...[
                      _buildMachineHeader(),
                      const SizedBox(height: 25),
                      const Text("Select Physical Slot to Fill:", style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1A3B70))),
                      const SizedBox(height: 10),
                      _buildSlotGrid(), 
                      const SizedBox(height: 30),
                      _buildConfigForm(),
                    ],
                  ],
                ),
              );
        },
      ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 1, role: "Caregiver", userEmail: widget.userEmail),
    );
  }

  Widget _buildConfigForm() {
    bool isLockedByOther = _machineSlots.isNotEmpty && _machineSlots[_selectedIndex]['status'] == "Occupied" && _machineSlots[_selectedIndex]['patientEmail'] != _currentTargetEmail;
    
    return Column(children: [
      AbsorbPointer(absorbing: isLockedByOther, child: Opacity(opacity: isLockedByOther ? 0.4 : 1.0, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _buildInputField("Physical Pill Content", _medDetailsController, Icons.inventory),
        const SizedBox(height: 20),
        Row(children: [
          Expanded(child: _buildDateTile("Start", _startDate, () => _selectDate(context, true))), 
          const SizedBox(width: 10), 
          Expanded(child: _buildDateTile("Until", _endDate, () => _selectDate(context, false)))
        ]),
        const SizedBox(height: 25),
        
        const Text("Dispense Frequency", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF1A3B70))),
        const SizedBox(height: 10),
        _buildFrequencyDropdown(),
        
        // INTERVAL INPUT: Only shows if "Every X Days" is selected
        if (_selectedFrequency == "Every X Days") 
          Padding(
            padding: const EdgeInsets.only(top: 15),
            child: _buildInputField("Interval (e.g., 2 for every other day)", _dayIntervalController, Icons.repeat, isNum: true),
          ),
          
        const SizedBox(height: 30),
        const Text("Alarms", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF1A3B70))),
        const SizedBox(height: 10),
        _buildTimeChips(),
        _buildTimePickerSection(),
      ]))),
      const SizedBox(height: 40),
      SizedBox(width: double.infinity, height: 55, child: ElevatedButton(onPressed: isLockedByOther ? null : _saveChanges, style: ElevatedButton.styleFrom(backgroundColor: isLockedByOther ? Colors.grey : const Color(0xFF1A3B70), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: Text(isLockedByOther ? "SLOT OCCUPIED" : "Sync & Lock Slot ${_selectedIndex + 1}", style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)))),
    ]);
  }

  Widget _buildFrequencyDropdown() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.grey.shade300)),
      child: DropdownButton<String>(
        value: _selectedFrequency,
        isExpanded: true, underline: const SizedBox(),
        items: ["Everyday", "No Repeat", "Every X Days"].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
        onChanged: (v) => setState(() {
          _selectedFrequency = v!;
          // Default interval to 2 if they select Every X Days for the first time
          if (v == "Every X Days" && _dayIntervalController.text.isEmpty) {
            _dayIntervalController.text = "2";
          }
        }),
      ),
    );
  }

  // --- UI HELPERS ---
  Widget _buildPatientDropdown(List<DocumentSnapshot> patients) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.shade300)),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _currentTargetEmail, isExpanded: true,
          hint: const Text("Select patient", style: TextStyle(fontSize: 14, color: Colors.grey)),
          items: patients.map((p) => DropdownMenuItem<String>(value: p.get('patientEmail').toString(), child: Text(p.get('patientEmail')))).toList(),
          onChanged: (val) { if (val != null) { setState(() => _currentTargetEmail = val); _fetchPatientMachineInfo(val); } },
        ),
      ),
    );
  }

  Widget _buildInputField(String label, TextEditingController controller, IconData icon, {bool isNum = false}) => TextField(
    controller: controller, 
    keyboardType: isNum ? TextInputType.number : TextInputType.text,
    decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), filled: true, fillColor: Colors.white)
  );

  Widget _buildDateTile(String label, DateTime date, VoidCallback onTap) => InkWell(onTap: onTap, child: Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.grey.shade300)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(fontSize: 10, color: Colors.grey, fontWeight: FontWeight.bold)), const SizedBox(height: 5), Row(children: [const Icon(Icons.calendar_today, size: 14, color: Color(0xFF1A3B70)), const SizedBox(width: 8), Text(DateFormat('MMM d').format(date), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))])])));
  
  Future<void> _selectDate(BuildContext context, bool isStart) async { 
    final DateTime? picked = await showDatePicker(context: context, initialDate: isStart ? _startDate : _endDate, firstDate: DateTime.now().subtract(const Duration(days: 365)), lastDate: DateTime(2030)); 
    if (picked != null) { setState(() { if (isStart) { _startDate = picked; if (_endDate.isBefore(_startDate)) _endDate = _startDate.add(const Duration(days: 1)); } else { _endDate = picked; } }); } 
  }

  Widget _buildTimeChips() => Wrap(spacing: 8, children: _currentMedTimes.map((time) => Chip(label: Text(time), deleteIcon: const Icon(Icons.cancel, size: 16), onDeleted: () => setState(() => _currentMedTimes.remove(time)), backgroundColor: Colors.blue.withOpacity(0.1))).toList());
  Widget _buildTimePickerSection() => Row(children: [Expanded(child: SizedBox(height: 100, child: CupertinoDatePicker(mode: CupertinoDatePickerMode.time, onDateTimeChanged: (t) => _pickerTime = t))), IconButton.filled(onPressed: _addTimeSlot, icon: const Icon(Icons.add_alarm))]);
  void _addTimeSlot() { String formatted = DateFormat("hh:mm a").format(_pickerTime); if (!_currentMedTimes.contains(formatted)) { setState(() { _currentMedTimes.add(formatted); _currentMedTimes.sort(); }); } }
  Widget _buildMachineHeader() => Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.blue.withOpacity(0.1), borderRadius: BorderRadius.circular(12)), child: Row(children: [const Icon(Icons.settings_remote, color: Color(0xFF1A3B70)), const SizedBox(width: 15), Text("Machine ID: ${_currentTargetMachineId ?? 'None'}", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13))]));
  Widget _buildPromptState(String msg) => Center(child: Padding(padding: const EdgeInsets.symmetric(vertical: 50), child: Column(children: [Icon(Icons.person_search_outlined, size: 60, color: Colors.blue.withOpacity(0.3)), const SizedBox(height: 15), Text(msg, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey, fontSize: 13))])));
  Widget _buildNoMachineWarning() => Container(width: double.infinity, padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: Colors.orange.shade50, borderRadius: BorderRadius.circular(15), border: Border.all(color: Colors.orange.shade200)), child: Column(children: [const Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 40), const SizedBox(height: 10), const Text("Hardware Not Linked", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), Text("This patient hasn't connected a dispenser yet.", textAlign: TextAlign.center, style: TextStyle(color: Colors.orange.shade900, fontSize: 12))]));
  Widget _buildEmptyState(String msg) => const Center(child: Text("No linked patients found."));

  Widget _buildSlotGrid() {
    return GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 5, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1), itemCount: 10, itemBuilder: (context, index) {
      bool isSelected = _selectedIndex == index;
      var slot = _machineSlots.length > index ? _machineSlots[index] : null;
      bool isOccupied = slot?['status'] == "Occupied";
      bool isMine = slot?['patientEmail'] == _currentTargetEmail;
      Color bgColor = isSelected ? const Color(0xFF1A3B70) : (isOccupied ? (isMine ? Colors.green.shade100 : Colors.red.shade100) : Colors.white);
      return GestureDetector(onTap: () => _loadSlotIntoForm(index), child: Container(decoration: BoxDecoration(color: bgColor, borderRadius: BorderRadius.circular(10), border: Border.all(color: isSelected ? Colors.blue : Colors.grey.shade300)), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text("${index + 1}", style: TextStyle(fontWeight: FontWeight.bold, color: isSelected ? Colors.white : Colors.black)), if (isOccupied) Icon(isMine ? Icons.person : Icons.lock, size: 10, color: isSelected ? Colors.white : Colors.black54)])));
    });
  }
}
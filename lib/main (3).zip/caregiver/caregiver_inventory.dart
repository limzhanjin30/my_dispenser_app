import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../custom_bottom_nav.dart';
import 'caregiver_dashboard.dart';

class CaregiverInventory extends StatefulWidget {
  final String userEmail;
  const CaregiverInventory({super.key, required this.userEmail});

  @override
  State<CaregiverInventory> createState() => _CaregiverInventoryState();
}

class _CaregiverInventoryState extends State<CaregiverInventory> {
  String? _selectedPatientEmail;
  String? _linkedMachineId;
  bool _isLoading = false;

  // --- DATABASE: LOOKUP PATIENT HARDWARE ---
  Future<void> _fetchMachineId(String pEmail) async {
    if (!mounted) return;
    setState(() {
      _isLoading = true;
      _linkedMachineId = null; // Reset machine ID during new fetch
    });
    
    try {
      var userSnap = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: pEmail.trim().toLowerCase())
          .limit(1)
          .get();

      if (userSnap.docs.isNotEmpty) {
        setState(() {
          _linkedMachineId = userSnap.docs.first.get('linkedMachineId');
          _isLoading = false;
        });
      } else {
        if (mounted) setState(() => _isLoading = false);
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // --- LOGIC: REFILL AND LOCK SLOT ---
  Future<void> _refillSlot(int index, List<dynamic> currentSlots) async {
    if (_linkedMachineId == null) return;

    setState(() => _isLoading = true);
    
    // Logic: Mark the bin as physically full and engage the lock
    currentSlots[index]['isDone'] = false; // Reset adherence flag for the next alarm
    currentSlots[index]['isLocked'] = true; // Signal hardware solenoid to lock

    try {
      await FirebaseFirestore.instance
          .collection('machines')
          .doc(_linkedMachineId)
          .update({'slots': currentSlots});
      
      _showMsg("Slot ${index + 1} refilled and locked.", Colors.teal);
    } catch (e) {
      _showMsg("Refill failed: $e", Colors.red);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showMsg(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: color));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F9FF),
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black, size: 20),
          onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => CaregiverDashboard(userEmail: widget.userEmail))),
        ),
        title: const Text("Refill Management", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16)),
        backgroundColor: Colors.white, elevation: 0.5, centerTitle: true,
      ),
      body: Column(
        children: [
          // 1. Patient Selector (Now starts with "Select Patient")
          _buildPatientSelector(),
          
          Expanded(
            child: _isLoading 
              ? const Center(child: CircularProgressIndicator())
              : _selectedPatientEmail == null 
                ? _buildEmptyState("Please select a patient from the dropdown to manage their hardware inventory.")
                : (_linkedMachineId == null 
                    ? _buildEmptyState("This patient has not connected a dispenser yet.")
                    : _buildInventoryGrid()),
          ),
        ],
      ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 3, role: "Caregiver", userEmail: widget.userEmail),
    );
  }

  Widget _buildPatientSelector() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('connections')
          .where('caregiverEmail', isEqualTo: widget.userEmail.trim().toLowerCase())
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const LinearProgressIndicator();
        var connections = snapshot.data!.docs;

        return Container(
          padding: const EdgeInsets.all(20),
          color: Colors.white,
          child: DropdownButtonFormField<String>(
            value: _selectedPatientEmail,
            hint: const Text("Select Patient", style: TextStyle(fontSize: 14, color: Colors.grey)), // FIXED: Explicit Hint
            decoration: InputDecoration(
              labelText: "Patient to Refill",
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
            ),
            items: connections.map((c) => DropdownMenuItem(value: c.get('patientEmail').toString(), child: Text(c.get('patientEmail')))).toList(),
            onChanged: (val) {
              if (val != null) {
                setState(() => _selectedPatientEmail = val);
                _fetchMachineId(val);
              }
            },
          ),
        );
      },
    );
  }

  Widget _buildInventoryGrid() {
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('machines').doc(_linkedMachineId).snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (!snapshot.hasData || !snapshot.data!.exists) return _buildEmptyState("Error: Machine configuration not found.");

        var data = snapshot.data!.data() as Map<String, dynamic>;
        List<dynamic> slots = data['slots'] ?? [];
        final String targetEmail = _selectedPatientEmail!.toLowerCase();

        // Filter: Only display bins assigned to the chosen patient
        List<dynamic> myPatientSlots = slots.where((s) => s['patientEmail'] == targetEmail && s['status'] == "Occupied").toList();

        if (myPatientSlots.isEmpty) return _buildEmptyState("This patient has no medications assigned to physical bins.");

        return ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          itemCount: slots.length,
          itemBuilder: (context, index) {
            var slot = slots[index];
            if (slot['patientEmail'] != targetEmail || slot['status'] == "Empty") return const SizedBox.shrink();

            bool needsRefill = slot['isDone'] == true; // isDone=true means medicine was taken and bin is empty

            return Card(
              margin: const EdgeInsets.only(bottom: 15),
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15), side: BorderSide(color: Colors.grey.shade200)),
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: needsRefill ? Colors.red.withOpacity(0.1) : Colors.green.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(needsRefill ? Icons.error_outline : Icons.check_circle_outline, 
                          color: needsRefill ? Colors.red : Colors.green, size: 24),
                    ),
                    const SizedBox(width: 15),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(slot['medDetails'] ?? "Medication", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                        const SizedBox(height: 2),
                        Text("Physical Slot ${slot['slot']}", style: const TextStyle(color: Colors.grey, fontSize: 11)),
                        const SizedBox(height: 5),
                        Text(needsRefill ? "BIN STATUS: EMPTY" : "BIN STATUS: FULL", 
                          style: TextStyle(color: needsRefill ? Colors.red : Colors.green, fontSize: 10, fontWeight: FontWeight.bold)),
                      ]),
                    ),
                    if (needsRefill)
                      ElevatedButton(
                        onPressed: () => _refillSlot(index, slots),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF1A3B70), 
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))
                        ),
                        child: const Text("Refill & Lock", style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                      )
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildEmptyState(String msg) {
    return Center(child: Padding(
      padding: const EdgeInsets.all(40.0), 
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.inventory_2_outlined, size: 50, color: Colors.blue.withOpacity(0.2)),
          const SizedBox(height: 15),
          Text(msg, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey, fontSize: 13, height: 1.5)),
        ],
      )
    ));
  }
}
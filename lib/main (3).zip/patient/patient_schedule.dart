import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'patient_dashboard.dart';
import 'patient_overall_schedule.dart'; 
import '../custom_bottom_nav.dart';

class PatientSchedule extends StatefulWidget {
  final String userEmail;
  final DateTime? initialDate; 

  const PatientSchedule({super.key, required this.userEmail, this.initialDate});

  @override
  State<PatientSchedule> createState() => _PatientScheduleState();
}

class _PatientScheduleState extends State<PatientSchedule> {
  late DateTime _selectedDate;
  String? _linkedMachineId;
  bool _isInitializing = true;

  @override
  void initState() {
    super.initState();
    _selectedDate = widget.initialDate ?? DateTime.now();
    _fetchMachineId();
  }

  // --- STEP 1: GET THE MACHINE ID FROM USER PROFILE ---
  Future<void> _fetchMachineId() async {
    try {
      var userSnap = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: widget.userEmail.trim().toLowerCase())
          .limit(1)
          .get();

      if (userSnap.docs.isNotEmpty) {
        setState(() {
          _linkedMachineId = userSnap.docs.first.get('linkedMachineId');
          _isInitializing = false;
        });
      }
    } catch (e) {
      debugPrint("Error fetching machine ID: $e");
      setState(() => _isInitializing = false);
    }
  }

  // --- LOGIC: SHOULD MEDICINE BE TAKEN ON THIS SPECIFIC DATE? ---
  bool _isMedActiveOnDate(Map<String, dynamic> med, DateTime date) {
    if (med['startDate'] == null || med['endDate'] == null || med['startDate'] == "") return false;

    DateTime start = DateTime.parse(med['startDate']);
    DateTime end = DateTime.parse(med['endDate']);
    
    DateTime checkDate = DateTime(date.year, date.month, date.day);
    DateTime startDate = DateTime(start.year, start.month, start.day);
    DateTime endDate = DateTime(end.year, end.month, end.day);

    if (checkDate.isBefore(startDate) || checkDate.isAfter(endDate)) return false;

    String freq = med['frequency'] ?? "Everyday";
    if (freq == "Everyday") return true;
    if (freq == "No Repeat") return checkDate.isAtSameMomentAs(startDate);

    if (freq.contains("Every") && freq.contains("Days")) {
      int days = int.tryParse(freq.split(' ')[1]) ?? 1;
      int difference = checkDate.difference(startDate).inDays;
      return difference % days == 0;
    }
    return true;
  }

  void _changeDate(int days) {
    setState(() => _selectedDate = _selectedDate.add(Duration(days: days)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F9FF),
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black, size: 20),
          onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => PatientDashboard(userEmail: widget.userEmail))),
        ),
        title: const Text("My Daily Schedule", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16)),
        actions: [
          IconButton(
            icon: const Icon(Icons.assignment_outlined, color: Color(0xFF1A3B70)),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => PatientOverallSchedule(userEmail: widget.userEmail))),
          ),
        ],
        backgroundColor: Colors.white,
        elevation: 0.5,
        centerTitle: true,
      ),
      body: _isInitializing 
          ? const Center(child: CircularProgressIndicator())
          : Column(
        children: [
          // --- DATE SELECTOR ---
          Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => _changeDate(-1)),
                Column(
                  children: [
                    Text(DateFormat('EEEE').format(_selectedDate), style: const TextStyle(color: Colors.blue, fontWeight: FontWeight.bold, fontSize: 12)),
                    Text(DateFormat('MMM d, yyyy').format(_selectedDate), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ],
                ),
                IconButton(icon: const Icon(Icons.chevron_right), onPressed: () => _changeDate(1)),
              ],
            ),
          ),

          // --- MACHINE-BASED SCHEDULE LIST ---
          Expanded(
            child: _linkedMachineId == null 
              ? _buildEmptyState("Machine not linked. Please contact your caregiver.")
              : StreamBuilder<DocumentSnapshot>(
              stream: FirebaseFirestore.instance.collection('machines').doc(_linkedMachineId).snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData || !snapshot.data!.exists) return _buildEmptyState("Machine data unavailable.");
                
                var data = snapshot.data!.data() as Map<String, dynamic>;
                List<dynamic> allSlots = data['slots'] ?? [];

                // FILTER: Only slots for THIS patient that are ACTIVE on the selected date
                List<dynamic> myMedsToday = allSlots.where((slot) {
                  bool belongsToMe = slot['patientEmail'] == widget.userEmail.trim().toLowerCase();
                  bool isOccupied = slot['status'] == "Occupied";
                  return belongsToMe && isOccupied && _isMedActiveOnDate(Map<String, dynamic>.from(slot), _selectedDate);
                }).toList();

                if (myMedsToday.isEmpty) return _buildEmptyState("No medication scheduled for this date.");

                return ListView.builder(
                  padding: const EdgeInsets.all(20),
                  itemCount: myMedsToday.length,
                  itemBuilder: (context, index) {
                    final med = myMedsToday[index];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 15),
                      child: ScheduleCard(
                        slotNumber: med['slot'].toString(),
                        times: List<String>.from(med['times'] ?? []),
                        medDetails: med['medDetails'] ?? "Medication Details",
                        mealCondition: med['mealCondition'] ?? "Anytime",
                        isDone: med['isDone'] ?? false,
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 1, role: "Patient", userEmail: widget.userEmail),
    );
  }

  Widget _buildEmptyState(String msg) {
    return Center(child: Padding(
      padding: const EdgeInsets.all(40.0),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.event_available, size: 60, color: Colors.grey),
        const SizedBox(height: 15),
        Text(msg, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey, fontSize: 14)),
      ]),
    ));
  }
}

class ScheduleCard extends StatelessWidget {
  final String slotNumber;
  final List<String> times;
  final String medDetails;
  final String mealCondition;
  final bool isDone;

  const ScheduleCard({super.key, required this.slotNumber, required this.times, required this.medDetails, required this.mealCondition, required this.isDone});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white, 
        borderRadius: BorderRadius.circular(15), 
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)]
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: const Color(0xFF1A3B70).withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                child: Text("Bin Slot $slotNumber", style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF1A3B70))),
              ),
              Icon(isDone ? Icons.check_circle : Icons.radio_button_unchecked, color: isDone ? Colors.green : Colors.grey),
            ],
          ),
          const SizedBox(height: 15),
          Text(medDetails, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF1A3B70))),
          const SizedBox(height: 5),
          Text(mealCondition, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.orange[800])),
          const Divider(height: 30),
          const Text("Alarm Times:", style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.grey)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: times.map((t) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(color: const Color(0xFFF5F9FF), borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.blue.withOpacity(0.2))),
              child: Text(t, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF1A3B70))),
            )).toList(),
          )
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../custom_bottom_nav.dart';
import '../login.dart';
import 'patient_schedule.dart'; 
import 'patient_link_machine.dart'; 

class PatientDashboard extends StatefulWidget {
  final String userEmail;
  const PatientDashboard({super.key, required this.userEmail});

  @override
  State<PatientDashboard> createState() => _PatientDashboardState();
}

class _PatientDashboardState extends State<PatientDashboard> with TickerProviderStateMixin {
  String fullName = "Patient";
  String? linkedMachineId;
  Map<String, dynamic>? nextDose;
  List<dynamic> todaySchedule = [];
  bool _isLoading = true;
  bool _isProcessingTaken = false;

  late AnimationController _pulseController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _initAnimation();
    _fetchUserAndMachineData();
  }

  void _initAnimation() {
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  // --- DATABASE: MARK AS TAKEN WITH GRACE PERIOD LOGIC ---
  Future<void> _markAsTaken() async {
    if (nextDose == null || linkedMachineId == null) return;
    setState(() => _isProcessingTaken = true);

    try {
      final String machineId = linkedMachineId!;
      final int targetSlot = nextDose!['slot'];
      final DateTime now = DateTime.now();
      final DateTime scheduledTime = nextDose!['fullTime'];
      
      // LOGIC: 30-minute grace period
      bool isLate = now.isAfter(scheduledTime.add(const Duration(minutes: 30)));
      String finalAdherenceStatus = isLate ? "Late" : "Taken";

      final String dateStr = DateFormat('yyyy-MM-dd').format(now);
      final String timeStr = DateFormat('hh:mm a').format(now);

      DocumentSnapshot machineDoc = await FirebaseFirestore.instance.collection('machines').doc(machineId).get();

      if (machineDoc.exists) {
        List<dynamic> slots = List.from(machineDoc.get('slots'));
        for (int i = 0; i < slots.length; i++) {
          if (slots[i]['slot'] == targetSlot) {
            slots[i]['isDone'] = true; 
            slots[i]['isLocked'] = false; 
            slots[i]['lastTakenDate'] = dateStr; 
            slots[i]['lastTakenTime'] = timeStr; 
            slots[i]['adherenceStatus'] = finalAdherenceStatus; // NEW: Persistence
            break;
          }
        }
        await FirebaseFirestore.instance.collection('machines').doc(machineId).update({'slots': slots});
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(isLate ? "Marked as LATE ($timeStr)" : "Marked as TAKEN ($timeStr)"), 
              backgroundColor: isLate ? Colors.orange : Colors.teal
            )
          );
        }
      }
    } catch (e) {
      debugPrint("Error confirm: $e");
    } finally {
      if (mounted) setState(() => _isProcessingTaken = false);
    }
  }

  // --- DATABASE: FETCHING ---
  Future<void> _fetchUserAndMachineData() async {
    final String cleanEmail = widget.userEmail.trim().toLowerCase();
    if (!mounted) return;
    setState(() => _isLoading = true);

    try {
      var userSnapshot = await FirebaseFirestore.instance.collection('users').where('email', isEqualTo: cleanEmail).limit(1).get();

      if (userSnapshot.docs.isNotEmpty) {
        var userData = userSnapshot.docs.first.data();
        fullName = userData['name'] ?? "Patient";
        linkedMachineId = userData['linkedMachineId'];

        if (linkedMachineId != null) {
          FirebaseFirestore.instance.collection('machines').doc(linkedMachineId).snapshots().listen((snap) {
            if (snap.exists && mounted) {
              _processMachineSlots(snap.data()!['slots'] ?? []);
            }
          });
        } else {
          if (mounted) setState(() => _isLoading = false);
        }
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // --- CORE LOGIC: PROCESS TODAY WITH GRACE PERIOD ---
  void _processMachineSlots(List<dynamic> slots) {
    DateTime now = DateTime.now();
    DateTime todayMidnight = DateTime(now.year, now.month, now.day);
    String todayStr = DateFormat('yyyy-MM-dd').format(now);
    
    List<Map<String, dynamic>> allFutureTimings = [];
    List<Map<String, dynamic>> todayDisplayList = [];
    final String myEmail = widget.userEmail.trim().toLowerCase();

    for (var slot in slots) {
      if (slot['patientEmail'] != myEmail || slot['status'] == "Empty") continue;
      
      DateTime start = DateTime.parse(slot['startDate'] ?? todayStr);
      DateTime end = DateTime.parse(slot['endDate'] ?? todayStr);
      DateTime startDateMidnight = DateTime(start.year, start.month, start.day);
      DateTime endDateMidnight = DateTime(end.year, end.month, end.day);

      bool isWithinRange = !todayMidnight.isBefore(startDateMidnight) && !todayMidnight.isAfter(endDateMidnight);
      if (!isWithinRange) continue;

      bool isIntervalMatch = _checkIntervalMatch(slot, todayMidnight, startDateMidnight);
      if (!isIntervalMatch) continue;

      bool isDoneToday = slot['lastTakenDate'] == todayStr;
      String persistenceAdherence = slot['adherenceStatus'] ?? "Taken";

      List<String> times = List<String>.from(slot['times'] ?? []);

      for (var t in times) {
        DateTime doseFullDateTime = _parseTimeString(t, todayMidnight);
        
        var doseMap = {
          "name": slot['medDetails'] ?? "Medication",
          "fullTime": doseFullDateTime,
          "displayTime": t,
          "isDone": isDoneToday,
          "adherenceStatus": persistenceAdherence,
          "slot": slot['slot'],
        };

        todayDisplayList.add(doseMap);

        // NEXT DOSE LOGIC: Include doses currently in the grace period
        if (!isDoneToday && doseFullDateTime.isAfter(now.subtract(const Duration(minutes: 30)))) {
          allFutureTimings.add(doseMap);
        }
      }
    }

    todayDisplayList.sort((a, b) => (a['fullTime'] as DateTime).compareTo(b['fullTime'] as DateTime));
    allFutureTimings.sort((a, b) => (a['fullTime'] as DateTime).compareTo(b['fullTime'] as DateTime));

    Map<String, dynamic>? upcoming = allFutureTimings.isNotEmpty ? allFutureTimings.first : null;

    if (upcoming != null) {
      Duration diff = upcoming['fullTime'].difference(now);
      // Pulse if due soon OR if 30-min window has already started
      if (diff.inMinutes < 15 && diff.inMinutes >= -30) {
        _pulseController.repeat(reverse: true);
      } else {
        _pulseController.stop();
      }
    }

    if (mounted) {
      setState(() {
        todaySchedule = todayDisplayList;
        nextDose = upcoming;
        _isLoading = false;
      });
    }
  }

  bool _checkIntervalMatch(dynamic slot, DateTime today, DateTime start) {
    String freq = slot['frequency'] ?? "Everyday";
    if (freq == "Everyday") return true;
    if (freq == "No Repeat") return today.isAtSameMomentAs(start);
    if (freq.contains("Every") && freq.contains("Days")) {
      try {
        int interval = int.parse(freq.split(' ')[1]);
        int dayDiff = today.difference(start).inDays;
        return dayDiff % interval == 0;
      } catch (e) { return true; }
    }
    return true;
  }

  DateTime _parseTimeString(String timeStr, DateTime referenceDate) {
    DateFormat format = DateFormat("hh:mm a");
    DateTime parsed = format.parse(timeStr);
    return DateTime(referenceDate.year, referenceDate.month, referenceDate.day, parsed.hour, parsed.minute);
  }

  String _getCountdownText(DateTime target) {
    Duration diff = target.difference(DateTime.now());
    if (diff.isNegative && diff.inMinutes.abs() < 30) return "DUE NOW";
    if (diff.isNegative) return "--";
    int h = diff.inHours, m = diff.inMinutes % 60;
    return "${h}h ${m}m";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F9FF),
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.logout, color: Colors.black87, size: 20), onPressed: () => Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) => const LoginPage()), (route) => false)),
        title: const Text("My Dashboard", style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent, elevation: 0, centerTitle: true,
      ),
      body: _isLoading 
        ? const Center(child: CircularProgressIndicator(color: Color(0xFF1A3B70)))
        : RefreshIndicator(
          onRefresh: _fetchUserAndMachineData,
          color: const Color(0xFF1A3B70),
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                const SizedBox(height: 25),
                linkedMachineId == null ? _buildLinkMachinePrompt() : _buildNextDoseCard(),
                const SizedBox(height: 30),
                const Text("Today's Schedule", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF1A3B70))),
                const SizedBox(height: 15),
                _buildScheduleList(),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 0, role: "Patient", userEmail: widget.userEmail),
    );
  }

  Widget _buildHeader() {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text("Hi, $fullName", style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF1A3B70))),
        Text(DateFormat('EEEE, MMM d').format(DateTime.now()), style: const TextStyle(color: Colors.grey, fontSize: 14)),
      ]),
      Icon(Icons.wifi, color: linkedMachineId != null ? Colors.green : Colors.grey, size: 20),
    ]);
  }

  Widget _buildNextDoseCard() {
    if (nextDose == null) return _buildStaticInfoCard("Schedule Complete", "All medications for today have been taken.");

    Duration diff = nextDose!['fullTime'].difference(DateTime.now());
    bool isWindowOpen = diff.inMinutes <= 0 && diff.inMinutes >= -30; // 30-min Grace Period logic
    bool isUrgent = diff.inMinutes < 15 && diff.inMinutes >= -30;

    Widget cardContent = Container(
      width: double.infinity, padding: const EdgeInsets.all(25),
      decoration: BoxDecoration(
        color: isUrgent ? const Color(0xFF1A3B70) : Colors.white, borderRadius: BorderRadius.circular(25),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 15)],
        border: isUrgent ? Border.all(color: Colors.red.shade200, width: 2) : Border.all(color: Colors.grey.shade100),
      ),
      child: Column(children: [
        Text(isWindowOpen ? "ACTION REQUIRED:" : "NEXT DOSE IN:", 
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: isUrgent ? Colors.white70 : Colors.blueGrey)),
        const SizedBox(height: 5),
        Text(_getCountdownText(nextDose!['fullTime']), style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold, color: isUrgent ? Colors.white : const Color(0xFF1A3B70), letterSpacing: -1)),
        Text("${nextDose!['name']} (Slot ${nextDose!['slot']})", style: TextStyle(color: isUrgent ? Colors.white : Colors.grey, fontSize: 16)),
        const SizedBox(height: 25),
        Row(children: [
          Expanded(child: OutlinedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => PatientSchedule(userEmail: widget.userEmail, initialDate: nextDose!['fullTime']))), style: OutlinedButton.styleFrom(side: BorderSide(color: isUrgent ? Colors.white70 : const Color(0xFF1A3B70)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 12)), child: Text("Details", style: TextStyle(color: isUrgent ? Colors.white : const Color(0xFF1A3B70), fontWeight: FontWeight.bold)))),
          const SizedBox(width: 15),
          Expanded(child: ElevatedButton(onPressed: _isProcessingTaken ? null : _markAsTaken, style: ElevatedButton.styleFrom(backgroundColor: isUrgent ? Colors.green : const Color(0xFF1A3B70), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 12)), child: _isProcessingTaken ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) : const Text("TAKEN", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)))),
        ])
      ]),
    );

    return isUrgent ? ScaleTransition(scale: _scaleAnimation, child: cardContent) : cardContent;
  }

  Widget _buildScheduleList() {
    DateTime now = DateTime.now();
    if (todaySchedule.isEmpty) return const Center(child: Text("No medications scheduled for today."));
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
      child: ListView.separated(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        itemCount: todaySchedule.length,
        separatorBuilder: (context, index) => Divider(height: 1, color: Colors.grey.shade50),
        itemBuilder: (context, index) {
          final item = todaySchedule[index];
          DateTime graceLimit = item['fullTime'].add(const Duration(minutes: 30));
          bool isPastGrace = now.isAfter(graceLimit);
          
          // Determine status based on persistent data and grace period
          String statusText = "UPCOMING";
          Color statusColor = Colors.blueGrey;
          IconData statusIcon = Icons.radio_button_off;

          if (item['isDone']) {
            statusText = item['adherenceStatus'].toString().toUpperCase();
            statusColor = item['adherenceStatus'] == "Late" ? Colors.orange : Colors.green;
            statusIcon = Icons.check_circle;
          } else if (isPastGrace) {
            statusText = "MISSED";
            statusColor = Colors.red;
            statusIcon = Icons.error_outline;
          }

          return ListTile(
            leading: Icon(statusIcon, color: statusColor),
            title: Text(item['displayTime'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xFF1A3B70))),
            subtitle: Text("${item['name']} (Slot ${item['slot']})"),
            trailing: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: statusColor.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
              child: Text(statusText, style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 10)),
            ),
          );
        },
      ),
    );
  }

  Widget _buildStaticInfoCard(String title, String sub) => Container(width: double.infinity, padding: const EdgeInsets.all(35), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(25), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)]), child: Column(children: [const Icon(Icons.verified_user_outlined, color: Colors.green, size: 45), const SizedBox(height: 15), Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF1A3B70))), const SizedBox(height: 5), Text(sub, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey, fontSize: 13))]));
  Widget _buildLinkMachinePrompt() => Container(width: double.infinity, padding: const EdgeInsets.all(30), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(25)), child: Column(children: [const Icon(Icons.link_off, color: Colors.orange, size: 50), const SizedBox(height: 15), const Text("Machine Not Connected", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => PatientLinkMachine(userEmail: widget.userEmail))), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1A3B70)), child: const Text("Link Device", style: TextStyle(color: Colors.white)))]));
}
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import '../custom_bottom_nav.dart';
import 'caregiver_dashboard.dart';

class CaregiverAdherence extends StatefulWidget {
  final String userEmail;
  const CaregiverAdherence({super.key, required this.userEmail});

  @override
  State<CaregiverAdherence> createState() => _CaregiverAdherenceState();
}

class _CaregiverAdherenceState extends State<CaregiverAdherence> {
  String? _selectedPatientEmail;
  String? _linkedMachineId;
  
  // Logic: Force current week to start on Monday
  DateTime _currentWeekStart = DateTime.now().subtract(Duration(days: DateTime.now().weekday - 1));

  void _changeWeek(int weeks) => setState(() => _currentWeekStart = _currentWeekStart.add(Duration(days: weeks * 7)));

  String _getWeekRangeString() {
    DateTime end = _currentWeekStart.add(const Duration(days: 6));
    return "${DateFormat('MMM d').format(_currentWeekStart)} - ${DateFormat('MMM d, yyyy').format(end)}";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F9FF),
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black, size: 20),
          onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => CaregiverDashboard(userEmail: widget.userEmail))),
        ),
        title: const Text("Weekly Adherence Audit", style: TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white, elevation: 0.5, centerTitle: true,
      ),
      body: Column(
        children: [
          _buildPatientSelector(),
          _buildWeekNavigator(),
          Expanded(
            child: _selectedPatientEmail == null 
              ? _buildEmptyState("Select a patient to audit their weekly adherence.")
              : _buildWeeklyLogsStream(),
          ),
        ],
      ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 2, role: "Caregiver", userEmail: widget.userEmail),
    );
  }

  Widget _buildPatientSelector() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('connections').where('caregiverEmail', isEqualTo: widget.userEmail.trim().toLowerCase()).snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const LinearProgressIndicator();
        var connections = snapshot.data!.docs;
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          color: Colors.white,
          child: DropdownButtonFormField<String>(
            value: _selectedPatientEmail,
            hint: const Text("Select Patient"),
            decoration: InputDecoration(labelText: "Clinical Monitoring", border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
            items: connections.map((c) {
              String cleanEmail = c.get('patientEmail').toString().toLowerCase().trim();
              return DropdownMenuItem(value: cleanEmail, child: Text(cleanEmail));
            }).toList(),
            onChanged: (val) {
              if (val != null) {
                setState(() {
                  _selectedPatientEmail = val;
                  _linkedMachineId = null; // Clear old machine association out to reload layout
                });
                _fetchPatientMachineId(val);
              }
            },
          ),
        );
      },
    );
  }

  // Helper logic to capture machine doc mapping ownership dynamically
  Future<void> _fetchPatientMachineId(String pEmail) async {
    try {
      var userDoc = await FirebaseFirestore.instance.collection('users')
          .where('email', isEqualTo: pEmail)
          .limit(1)
          .get();
      if (userDoc.docs.isNotEmpty && mounted) {
        setState(() {
          _linkedMachineId = userDoc.docs.first.data()['linkedMachineId'];
        });
      }
    } catch (e) {
      debugPrint("Machine ID Lookup Error: $e");
    }
  }

  Widget _buildWeekNavigator() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
      color: Colors.white,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => _changeWeek(-1)),
          Column(children: [
            const Text("CURRENT WEEK", style: TextStyle(fontSize: 10, color: Colors.blue, fontWeight: FontWeight.bold)),
            Text(_getWeekRangeString(), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          ]),
          IconButton(icon: const Icon(Icons.chevron_right), onPressed: () => _changeWeek(1)),
        ],
      ),
    );
  }

  // --- REVISED STREAM CONTAINER: STREAMS DATA FROM EMBEDDED MACHINE DOCUMENT ---
  Widget _buildWeeklyLogsStream() {
    if (_linkedMachineId == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('machines').doc(_linkedMachineId).snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) return _buildEmptyState("Error loading logs. Check internet permissions.");
        if (!snapshot.hasData || !snapshot.data!.exists) return _buildEmptyState("No active hardware hardware logs associated with this account.");
        
        var machineData = snapshot.data!.data() as Map<String, dynamic>;
        List<dynamic> fullHistoryArray = machineData['adherenceHistory'] ?? [];

        // Parse week bounds parameters for accurate calculation comparisons
        DateTime startWeek = DateTime(_currentWeekStart.year, _currentWeekStart.month, _currentWeekStart.day);
        DateTime endWeek = startWeek.add(const Duration(days: 7));

        // --- IN-MEMORY FILTER PROCESS ---
        List<Map<String, dynamic>> filteredWeeklyItems = [];
        for (var item in fullHistoryArray) {
          var data = item as Map<String, dynamic>;
          String dateStr = data['date'] ?? "";
          if (dateStr.isNotEmpty) {
            try {
              DateTime itemDate = DateTime.parse(dateStr);
              // Check if logs sit explicitly inside the Monday-to-Sunday viewing timeline scope
              if ((itemDate.isAtSameMomentAs(startWeek) || itemDate.isAfter(startWeek)) && itemDate.isBefore(endWeek)) {
                filteredWeeklyItems.add(data);
              }
            } catch (e) {
              debugPrint("Date alignment exception parse log: $e");
            }
          }
        }

        // Group dynamically processed list elements in local map tables
        Map<String, List<Map<String, dynamic>>> masterMap = {};
        for (var data in filteredWeeklyItems) {
          String recordDate = data['date'] ?? "Unknown";
          masterMap.putIfAbsent(recordDate, () => []).add(data);
        }

        DateTime now = DateTime.now();
        DateTime todayMidnight = DateTime(now.year, now.month, now.day);

        return ListView.builder(
          padding: const EdgeInsets.all(20),
          itemCount: 7, 
          itemBuilder: (context, dayIndex) {
            DateTime currentDay = _currentWeekStart.add(Duration(days: dayIndex));
            String dayStr = DateFormat('yyyy-MM-dd').format(currentDay);
            
            List<Map<String, dynamic>> dayItems = List.from(masterMap[dayStr] ?? []);

            // Sort nested maps chronologically by scheduling time strings
            dayItems.sort((a, b) {
              String tA = (a['times'] is List && (a['times'] as List).isNotEmpty) ? (a['times'] as List).first : "00:00 AM";
              String tB = (b['times'] is List && (b['times'] as List).isNotEmpty) ? (b['times'] as List).first : "00:00 AM";
              return tA.compareTo(tB);
            });

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Text(DateFormat('EEEE, MMM d').format(currentDay), 
                    style: TextStyle(fontWeight: FontWeight.bold, color: currentDay.isAtSameMomentAs(todayMidnight) ? Colors.blue : Colors.blueGrey)),
                ),
                if (dayItems.isEmpty) 
                  const Padding(padding: EdgeInsets.only(left: 10, bottom: 10), child: Text("No medication activity logs.", style: TextStyle(color: Colors.grey, fontSize: 11))),
                
                ...dayItems.map((item) {
                  String displayStatus = item['adherenceStatus'] ?? "Upcoming";
                  String sched = (item['times'] is List && (item['times'] as List).isNotEmpty) ? (item['times'] as List).first : "--:--";
                  String actual = item['takenTime'] ?? item['lastTakenTime'] ?? "";

                  // If still "Upcoming" but time bounds have elapsed (+30 minutes margin check)
                  if (displayStatus.toLowerCase() == "upcoming" && sched != "--:--") {
                    try {
                      DateTime st = DateFormat("hh:mm a").parse(sched);
                      DateTime fullSched = DateTime(currentDay.year, currentDay.month, currentDay.day, st.hour, st.minute);
                      if (now.isAfter(fullSched.add(const Duration(minutes: 30)))) {
                        displayStatus = "Missed";
                      }
                    } catch (e) {}
                  }

                  return _buildAdherenceCard(item, displayStatus, sched, actual);
                }),
                const Divider(height: 30),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildAdherenceCard(Map<String, dynamic> item, String displayStatus, String scheduledTime, String actualTime) {
    String med = item['medDetails'] ?? item['medName'] ?? "Medicine";
    int bin = item['slot'] ?? 0;

    Color color; IconData icon; String subText;

    switch (displayStatus.toLowerCase()) {
      case "taken":
        color = Colors.green; icon = Icons.check_circle;
        subText = "Taken at $actualTime (Scheduled: $scheduledTime)";
        break;
      case "late":
        color = Colors.orange; icon = Icons.watch_later;
        subText = "Taken LATE at $actualTime (Scheduled: $scheduledTime)";
        break;
      case "missed":
        color = Colors.red; icon = Icons.error_outline;
        subText = "Missed: Dose was scheduled for $scheduledTime";
        break;
      default:
        color = Colors.blueGrey; icon = Icons.timer_outlined;
        subText = "Upcoming: Dose scheduled for $scheduledTime";
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8, offset: const Offset(0, 4))]),
      child: IntrinsicHeight(
        child: Row(
          children: [
            Container(width: 5, decoration: BoxDecoration(color: color, borderRadius: const BorderRadius.only(topLeft: Radius.circular(12), bottomLeft: Radius.circular(12)))),
            const SizedBox(width: 15),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 15), 
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(med, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 4),
                  Text("Bin $bin • $subText", style: const TextStyle(fontSize: 10, color: Colors.black54)),
                ])
              )
            ),
            Padding(
              padding: const EdgeInsets.only(right: 15), 
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(icon, color: color, size: 18),
                const SizedBox(height: 4),
                Text(displayStatus.toUpperCase(), style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 8)),
              ])
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(String msg) => Center(child: Padding(padding: const EdgeInsets.all(40.0), child: Text(msg, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey, fontSize: 13))));
}